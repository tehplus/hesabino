<div class="logo text-center mb-4">
    <h3 class="text-white">حسابینو</h3>
</div>
<nav class="nav flex-column">
    <a href="index.php" class="nav-link">
        <i class="bi bi-house-fill"></i>
        داشبورد
    </a>
        <a href="?page=add-product" class="nav-link">
        <i class="bi bi-plus-circle"></i>
        افزودن محصول جدید
    </a>
    <a href="?page=products" class="nav-link">
        <i class="bi bi-box-seam"></i>
        لیست محصولات
    </a>

    <a href="?page=services" class="nav-link">
        <i class="bi bi-gear"></i>
        خدمات
    </a>
    <a href="?page=categories" class="nav-link">
        <i class="bi bi-folder"></i>
        دسته‌بندی‌ها
    </a>
    <a href="?page=new-sale" class="nav-link">
        <i class="bi bi-cart-plus"></i>
        فروش جدید
    </a>
    <a href="?page=quick-invoice" class="nav-link">
        <i class="bi bi-receipt"></i>
        فاکتور سریع
    </a>
</nav>